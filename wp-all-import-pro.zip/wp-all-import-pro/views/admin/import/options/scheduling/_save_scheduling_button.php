<div class="wpai-save-scheduling-button rad10 button button-primary button-hero wpallexport-large-button"
     style="position: relative; ">
    <svg width="30" height="30" viewBox="0 0 1792 1792"
         xmlns="http://www.w3.org/2000/svg"
         style="fill: white; display: none;">
        <path
            d="M1671 566q0 40-28 68l-724 724-136 136q-28 28-68 28t-68-28l-136-136-362-362q-28-28-28-68t28-68l136-136q28-28 68-28t68 28l294 295 656-657q28-28 68-28t68 28l136 136q28 28 28 68z"
            fill="white"/>
    </svg>
    <div class="easing-spinner" style="display: none; left: 16px !important; top: 12px;">
        <div class="double-bounce1"></div>
        <div class="double-bounce2"></div>
    </div>
    <div class="save-text"
         style="display: block; position:absolute; left: 60px; top:6px; user-select: none; ">
            <?php _e('Confirm & Run Import', PMXI_Plugin::LANGUAGE_DOMAIN); ?>
    </div>
</div>